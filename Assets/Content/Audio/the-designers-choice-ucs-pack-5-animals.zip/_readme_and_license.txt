Pack downloaded from Freesound
----------------------------------------

"The Designer&#x27;s Choice UCS Pack #5 - ANIMALS"

This Pack of sounds contains sounds by the following user:
 - designerschoice ( https://freesound.org/people/designerschoice/ )

You can find this pack online at: https://freesound.org/people/designerschoice/packs/43408/


Pack description
----------------

A complete collection of animals great and small like amphibians, aquatic animals, bats, domestic cats, wild cats, domestic dogs, wild dogs, farm animals, equestrian animals (horses, donkeys, zebras), insects, misc. animals, primates, reptiles, rodents and wild animals recorded, edited and designed by Nicholas A. Judy at The Designer&#x27;s Choice.

All sound effects are available to you on a complete royalty-free basis. Use these in many personal and commercial projects.

You can credit me or not.

Amphibian Categories: Frog, Toad, Newt

Amphibian - Frog Species: African Bullfrog, Amazon Milk Frog, American Bullfrog, American Green Tree Frog, Australian Green Tree Frog, Barking Tree Frog, Big Eyed Tree Frog, Boreal Chorus Frog, California Tree Frog, Canyon Tree Frog, Chinese Gliding Frog, Coqui, Cuban Tree Frog, Desert Rain Frog, Dwarf Pixie Frog, European Tree Frog, Gliding Tree Frog, Golden Coqui, Gray Tree Frog, Green Frog, Leopard Tree Frog, Mountain Chorus Frog, Northern Green Frog, Northern Leopard Frog, Orange Thighed Tree Frog, Pacific Tree Frog, Pickerel Frog, Plains Leopard Frog, Red Eyed Tree Frog, Reticulated Glass Frog, Rio Grande Chirping Frog, Southern Leopard Frog, Spring Peeper, Squirrel Tree Frog, Upland Chorus Frog, Western Chorus Frog, White&#x27;s Tree Frog

Amphibian - Toad Species: American Toad, Canadian Toad, Cane Toad, Common Toad, Eastern American Toad, Eastern Spadefoot Toad, European Green Toad, Golden Toad, Plains Spadefoot Toad, Southern Toad, Texas Toad, Western Spadefoot Toad

Aquatic Animal Categories: Crab, Crayfish, Dolphin, Electric Eel, Fish, Hermit Crab, Lobster, Orca, Otter, Piranha, Porpoise, Sea Lion, Seal, Shark, Stingray, Walrus, Whale

Aquatic Animal - Whale Species: Beluga Whale, Blue Whale, Grey Whale, Humpback Whale, Narwhal

Bat Species: Big Brown Bat, Hoary Bat, Mexican Free-Tailed Bat, Tricolor Bat, Vampire Bat

Domestic Cat Species: Kitten, Mog, Persian, Tabby, Siamese, Sphinx

Wild Cat Categories: Bobcat, Caracal, Fishing Cat, Leopard, Lion, Pallas&#x27; Cat, Puma, Tiger

Dog Species: Bulldog, Foxhound, German Shepherd, Gordon Setter, Great Dane, Husky, Pomeranian, Puppy, Rottweiler, Shepherd, Spaniel, Terrier

Wild Dog Categories: Coyote, Dingo, Fox, Jackal, Maned Wolf, Wolf

Farm Animal Categories: Bull, Cow, Goat, Llama, Pig, Sheep

Horse Categories: Donkey, Horse, Mule

Insect Categories: Ant, Bee, Butterfly, Cicada, Cricket, Fly, Hornet, Madagascar Hissing Cockroach, Mosquito, Spider, Swarm, Wasp

Primate Categories: Ape, Aye-Aye, Baboon, Bonobo, Bush Baby, Capuchin Monkey, Chimpanzee, Colobus, Common Woolly Monkey, Galago, Gibbon, Gorilla, Howler Monkey, Lemur, Lion Tamarin, Loris, Macaque, Mandrill, Mangabey, Marmoset, Monkey, Night Monkey, Orangutan, Probiscis Monkey, Saki, Siamang, Southern Muriqui, Spider Monkey, Squirrel Monkey, Tamarin, Tarsier, Titi Monkey, Uakari, Vervet

Baboon Species: Chacma Baboon, Hamadryas Baboon

Capuchin Monkey Species: Azara&#x27;s Capuchin, Black-Striped Capuchin, Chestnut Capuchin, Crested Capuchin, Golden-Bellied Capuchin

Gibbon Species: Lar Gibbon, White-Cheeked Gibbon

Gorilla Species: Mountain Gorilla

Howler Monkey Species: Black Howler, Mantled Howler, Northern Brown Howler

Lemur Species: Collared Lemur, Coquerel&#x27;s Sifaka, Crowned Lemur, Red Ruffed Lemur, Ring-Tailed Lemur

Lion Tamarin Species: Golden Lion Tamarin

Loris Species: Pygmy Slow Loris

Macaque Species: Bonnet Macaque, Japanese Macaque

Marmoset Species: Black-Tailed Marmoset, Common Marmoset, Silvery Marmoset, Western Pygmy Marmoset

Night Monkey Species: Black-Headed Night Monkey, Spix&#x27;s Night Monkey

Orangutan Species: Bornean Orangutan

Spider Monkey Species: Black-Headed Spider Monkey

Squirrel Monkey Species: Collins&#x27; Squirrel Monkey, Guinean Squirrel Monkey

Tamarin Species: Bearded Emperor Tamarin, Black Tamarin, Brown-Mantled Tamarin, Cotton-Top Tamarin, Golden-Mantled Tamarin, Moustached Tamarin, White-Lipped Tamarin

Titi Monkey Species: Brown Titi Monkey, Toppin&#x27;s Titi Monkey, White-Tailed Titi Monkey

Reptile Categories: Alligator, Anaconda, Chameleon, Cobra, Crocodile, Iguana, Komodo Dragon, Lizard, Monitor, Puff Adder, Python, Rattlesnake, Snake, Tortoise, Turtle, Viper

Rodent Categories: Armadillo, Beaver, Capybara, Chinchilla, Chipmunk, Echidna, Ferret, Gopher, Guinea Pig, Hamster, Lesser Madagascar Hedgehog Tenrec, Marmot, Meerkat, Mink, Mole, Mouse, Naked Mole-Rat, Porcupine, Prairie Dog, Racoon, Rat, Red Panda, Shrew, Skunk, Squirrel, Vole

Wild Animal Categories: Agouti, Bandicoot, Bear, Binturong, Brush-Tailed Bettong, Buffalo, Camel, Caribou, Coatis, Deer, Elephant, Elk, Hippopotamus, Hyena, Hyrax, Ibex, Koala, Mongoose, Opossum, Rabbit, Rhinoceros, Wildebeest

Bear Species: American Black Bear, Giant Panda, Grizzly Bear, Polar Bear, Spectacled Bear

Sound Recorders and Microphones Used: Blue Snowball Microphone, Samsung Galaxy Smartphone


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 803729__designerschoice__anmlwild-samsung-galaxy-smartphone-cu_elephant-trumpet-human-imitation-sounds-realistic_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803729/
    * license: Creative Commons 0
  * 803727__designerschoice__anmlrept-blue-snowball-microphone_snake-strike_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803727/
    * license: Creative Commons 0
  * 803726__designerschoice__anmlrept-blue-snowball-microphone_snake-hiss-simulated-vocal_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803726/
    * license: Creative Commons 0
  * 803724__designerschoice__anmlhors-samsung-galaxy-smartphone-cu_donkey-braying_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803724/
    * license: Creative Commons 0
  * 803723__designerschoice__anmldog_mutt-sniffing-quickly-two-long-sniffs_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803723/
    * license: Creative Commons 0
  * 803722__designerschoice__anmldog_mutt-head-shake-slobber_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803722/
    * license: Creative Commons 0
  * 803721__designerschoice__anmldog_jasper-whimper_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803721/
    * license: Creative Commons 0
  * 803720__designerschoice__anmldog_jasper-panting_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803720/
    * license: Creative Commons 0
  * 803719__designerschoice__anmldog_jasper-barking-yipping_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803719/
    * license: Creative Commons 0
  * 803718__designerschoice__anmldog_dog-whimpering-sneeze-at-end_nicholas-judy_dc01.wav.wav
    * url: https://freesound.org/s/803718/
    * license: Creative Commons 0
  * 803717__designerschoice__anmldog-samsung-galaxy-smartphone_scratching-for-fleas_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803717/
    * license: Creative Commons 0
  * 803716__designerschoice__anmldog-samsung-galaxy-smartphone-mcu_rottweiler-puppies-howling-barking_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803716/
    * license: Creative Commons 0
  * 803715__designerschoice__anmldog-samsung-galaxy-smartphone-distant_rottweiler-puppies-howling-barking-thru-window_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803715/
    * license: Creative Commons 0
  * 803714__designerschoice__anmldog-samsung-galaxy-smartphone-cu_large-dog-barking_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803714/
    * license: Creative Commons 0
  * 803713__designerschoice__anmldog-samsung-galaxy-smartphone-cu_cavalier-poodle-barking_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803713/
    * license: Creative Commons 0
  * 803712__designerschoice__anmldog-samsung-galaxy-smartphone-cu_aggresive-dog-barks-and-snarls-distant-wind-chimes_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803712/
    * license: Creative Commons 0
  * 803711__designerschoice__anmldog-samsung-galaxy-smartphone-cu_aggessive-dog-barks-snarls-inside-window_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803711/
    * license: Creative Commons 0
  * 803594__designerschoice__anmlcat_cat-tail-hits-on-furniture-light-pat_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803594/
    * license: Creative Commons 0
  * 803593__designerschoice__anmlcat_cat-purring-looped_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803593/
    * license: Creative Commons 0
  * 803592__designerschoice__anmlcat_cat-meowing_the-designers-choice_gnrl1.mp3.mp3
    * url: https://freesound.org/s/803592/
    * license: Creative Commons 0
  * 803591__designerschoice__anmlcat-samsung-galaxy-smartphone-cu_sad-meows_the-designers-choice_gnrl1.wav.wav
    * url: https://freesound.org/s/803591/
    * license: Creative Commons 0
  * 803590__designerschoice__anmlcat-blue-snowball-microphone-cu_kitten-meow_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803590/
    * license: Creative Commons 0
  * 803589__designerschoice__anmlcat-blue-snowball-microphone-cu_hiss_nicholas-judy_tdc.wav.wav
    * url: https://freesound.org/s/803589/
    * license: Creative Commons 0


